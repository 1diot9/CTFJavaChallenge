#!/bin/bash

nginx
su - java -c "`which java` -jar /app/app.jar"
tail -f /dev/null